var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/sendAppointmentEmail/route.js")
R.c("server/chunks/[root-of-the-server]__c1f7829c._.js")
R.c("server/chunks/[root-of-the-server]__0e515441._.js")
R.c("server/chunks/[root-of-the-server]__df7d6ded._.js")
R.m(20000)
R.m(21455)
module.exports=R.m(21455).exports
