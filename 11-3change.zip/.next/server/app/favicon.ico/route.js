var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__827bc745._.js")
R.c("server/chunks/[root-of-the-server]__38b51b6c._.js")
R.c("server/chunks/node_modules_next_68e9acd2._.js")
R.m(15934)
R.m(17951)
module.exports=R.m(17951).exports
