module.exports=[93695,(a,b,c)=>{b.exports=a.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},62212,a=>{a.n(a.i(66114))},64687,(a,b,c)=>{},29448,a=>{"use strict";a.s(["default",()=>c]);var b=a.i(7997);let c=()=>(0,b.jsx)("div",{children:"salesprocess"})}];

//# sourceMappingURL=%5Broot-of-the-server%5D__c950811d._.js.map