module.exports=[15464,a=>{"use strict";a.s(["zodiak",()=>b.default]);var b=a.i(61861)}];

//# sourceMappingURL=app_zodiak_18057800_307b16a8.js.map