globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/47d465302263b8c4.js",
      "static/chunks/turbopack-46c24c944d1d29d5.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/47d465302263b8c4.js",
      "static/chunks/turbopack-40cbf82ff0fc07f6.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/2e175d805581124f.js",
    "static/chunks/47f477e3d2ef265b.js",
    "static/chunks/150316a471952cee.js",
    "static/chunks/8082ab48faca5ea1.js",
    "static/chunks/turbopack-e284afe938f63c1e.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];