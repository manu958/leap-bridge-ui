__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/47d465302263b8c4.js",
  "static/chunks/turbopack-46c24c944d1d29d5.js"
])
