__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/47d465302263b8c4.js",
  "static/chunks/turbopack-40cbf82ff0fc07f6.js"
])
